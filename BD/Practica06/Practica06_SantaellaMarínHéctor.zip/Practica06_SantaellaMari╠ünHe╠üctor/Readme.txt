Luis Gerardo Bernabe Gómez
luis_berna@ciencias.unam.mx
312225430
Héctor Santaella Marín
santaella@ciencias.unam.mx
312243212
Práctica 06
