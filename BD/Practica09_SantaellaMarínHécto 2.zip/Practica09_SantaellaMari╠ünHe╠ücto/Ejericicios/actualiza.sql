UPDATE Persona
SET Nombre= 'Alfred Schmidt', Telefono= '576340446'
WHERE pk_id_persona = 1;

UPDATE Persona
SET Nombre= 'Jose Jesus', Edad= '45'
WHERE pk_id_persona = 45;

UPDATE Persona
SET Nombre= 'Andres Calamardo'
WHERE pk_id_persona = 54;

UPDATE Persona
SET Nombre= 'Luis Bernabe', Edad= '65'
WHERE pk_id_persona = 56;


UPDATE Persona
SET Edad='22'
WHERE pk_id_persona = 50;

UPDATE Persona
SET Nombre= 'Jesus Salazar', Edad= '45'
WHERE pk_id_persona = 43;

UPDATE Persona
SET Nombre= 'Jesus Salazar', Edad= '23'
WHERE pk_id_persona = 32;

UPDATE Persona
SET  Edad= '45'
WHERE pk_id_persona = 1;


UPDATE Persona
SET Edad=43
WHERE pk_id_persona = 1;

UPDATE Persona
SET  Edad=45
WHERE pk_id_persona = 78;


UPDATE Clase
SET dia_semana ='Martes'
WHERE pk_id_clase = 1;

UPDATE Clase
SET  dia_semana='Jueves'
WHERE pk_id_clase = 2;

UPDATE Clase
SET  dia_semana='Viernes'
WHERE pk_id_clase = 3;

UPDATE Clase
SET dia_semana='Sabado'
WHERE pk_id_clase = 4;

UPDATE Clase
SET dia_semana='Viernes'
WHERE pk_id_clase = 13;

UPDATE Clase
SET  dia_semana='Lunes'
WHERE pk_id_clase = 1;

UPDATE Clase
SET dia_semana='Lunes'
WHERE pk_id_clase = 22;

UPDATE Clase
SET dia_semana='Jueves'
WHERE pk_id_clase = 39;

UPDATE Clase
SET dia_semana='Viernes'
WHERE pk_id_clase = 21;




UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =234;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =209;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =202;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =284;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =278;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =229;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =276;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =223;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =211;

UPDATE Cliente
SET fecha_registro='11-05-95'
WHERE pk_id_cliente =215;
