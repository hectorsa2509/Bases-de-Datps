delete from Persona;
delete from Entrenador;
delete from Instructor;
delete from Socio;
delete from Cliente;
delete from Clase;
delete from Area;
delete from Visita;
delete from Membresia;
delete from Tener;
delete from Producto;
delete from Nombre_Clase;
delete from TipoMembresia;


