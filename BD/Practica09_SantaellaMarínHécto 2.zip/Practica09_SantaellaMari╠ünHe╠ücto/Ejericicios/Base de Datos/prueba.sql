/*No lo inserta debido que la edad es menor a 0*/

INSERT INTO Persona(pk_id_persona,Nombre,Fecha_Nac,Edad,Sexo,Telefono,Email) VALUES (600,'Autumn Gonzales','11-05-95',-54,'M','049-631-1758','Aliquam.gravida@Maurisblanditenim.ca');
/*Acepta*/
INSERT INTO Persona(pk_id_persona,Nombre,Fecha_Nac,Edad,Sexo,Telefono,Email) VALUES (693,'Bradley Lowery','03-10-00',23,'M','057-678-4598','ligula.Donec@convallisantelectus.ca');
